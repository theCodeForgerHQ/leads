"""Decide whether a job is a software role.

Two signals, in order of trust:

1. YC's own ``role`` facet (default: ``eng``). This is the authoritative
   classification and is what we rely on by default.
2. A title regex fallback, for the occasional role that is genuinely software
   but tagged under a different facet (a "Founding Engineer" filed as "other",
   say). It is paired with an exclude regex so that a hard-tech company's
   mechanical / electrical / hardware engineering roles do *not* get pulled in
   under a broad eng tag -- "software related" should mean software.

The exclude check runs first and wins: a "Mechanical Engineer" never counts,
regardless of facet. This trades a sliver of recall for precision, which is the
right call when the requirement is strict accuracy.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .config import Config
from .models import Job


@dataclass(frozen=True)
class SoftwareClassifier:
    roles: frozenset[str]
    fallback_enabled: bool
    include_re: re.Pattern
    exclude_re: re.Pattern

    @classmethod
    def from_config(cls, cfg: Config) -> "SoftwareClassifier":
        def compile_any(patterns: list[str]) -> re.Pattern:
            # Match if ANY pattern hits; empty -> a regex that never matches.
            joined = "|".join(f"(?:{p})" for p in patterns) or r"(?!x)x"
            return re.compile(joined, re.IGNORECASE)

        return cls(
            roles=frozenset(r.lower() for r in cfg.software_roles),
            fallback_enabled=cfg.title_fallback.enabled,
            include_re=compile_any(cfg.title_fallback.include_patterns),
            exclude_re=compile_any(cfg.title_fallback.exclude_patterns),
        )

    def is_software(self, job: Job) -> bool:
        title = (job.title or "")
        if self.exclude_re.search(title):
            return False
        if job.role and job.role.lower() in self.roles:
            return True
        if self.fallback_enabled and self.include_re.search(title):
            return True
        return False
